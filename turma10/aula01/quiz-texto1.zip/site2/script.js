// Controle
let atual = 0;
let tempo = 15;
let intervalo;

// Elementos
const elPergunta = document.getElementById("pergunta");
const elTimer = document.getElementById("timer");
const elRespostas = document.querySelectorAll(".btn");

// Iniciar jogo
carregarPergunta();

// Carregar pergunta
function carregarPergunta() {
  const perguntaAtual = perguntas[atual];

  elPergunta.innerText = perguntaAtual.pergunta;

  // reset visual dos botões
  elRespostas.forEach(btn => {
    btn.style.background = "";
    btn.style.opacity = "1";
    btn.disabled = false;
  });

  iniciarTimer();
}

// Timer
function iniciarTimer() {
  tempo = 15;
  elTimer.innerText = tempo;

  intervalo = setInterval(() => {
    tempo--;
    elTimer.innerText = tempo;

    if (tempo === 0) {
      clearInterval(intervalo); 
      setTimeout(proximaPergunta, 2000);
    }
  }, 1000);
}

// Clique do usuário
function responder(indice) {
  clearInterval(intervalo);

  if (indice === perguntas[atual].correta) {
    elTimer.innerText = "Acertou!";
  } else {
    elTimer.innerText = "Errou!";
  }
   
  setTimeout(proximaPergunta, 2000);
}

// Próxima pergunta
function proximaPergunta() {
  atual++;

  if (atual < perguntas.length) {
    carregarPergunta();
  } else {
    document.body.innerHTML = "<h1>Fim do jogo!</h1>";
  }
}