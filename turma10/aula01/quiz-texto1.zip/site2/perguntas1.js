// Perguntas
const perguntas = [
  {
    pergunta: "1: Ter muitos dados garante que teremos conhecimento de qualidade.",
    correta: 1 // 1 = Falso
  },
  {
    pergunta: "2: A ciência de dados busca organizar informações para ajudar na tomada de decisões.",
    correta: 0 
  },
  {
    pergunta: "3: Tomar decisões baseadas apenas no senso comum pode levar a erros.",
    correta: 0 // 0 = Verdadeiro  
  },
  {
    pergunta: "4: A Ciência de Dados surgiu apenas com o avanço recente da tecnologia.",
    correta: 1 
  },
  {
    pergunta: "5: Segundo o texto, o cientista de dados deve agir como um detetive, buscando padrões.",
    correta: 0
  },
  {
    pergunta: "6: A empresa Netflix toma decisões apenas com base na opinião de seus diretores.",
    correta: 1 
  },
  {
    pergunta: "7: Ferramentas tecnológicas são mais importantes que o pensamento crítico na análise de dados.",
    correta: 1 
  },
  {
    pergunta: "8: Um levantamento de dados sem organização prévia torna-se mais difícil de dar certo.",
    correta: 0 
  },
  {
    pergunta: "9: Classificar corretamente um problema depende de observar seu principal impacto.",
    correta: 0 
  },
  {
    pergunta: "10: A Ciência de Dados só é útil para empresas de tecnologia e não tem relação com a escola ou o meio ambiente.",
    correta: 1 
  }
];